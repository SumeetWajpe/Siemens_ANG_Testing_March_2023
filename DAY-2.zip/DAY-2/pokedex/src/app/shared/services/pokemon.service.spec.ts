import { PokemonService } from "./pokemon.service";
import { TestBed, waitForAsync } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
describe("pokemon service  ", () => {
  let pokemonServiceObj: PokemonService;

  let httpClientMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PokemonService],
    });
    pokemonServiceObj = TestBed.inject(PokemonService);
    httpClientMock = TestBed.inject(HttpTestingController);
  });

  it("should check if a service object is created ", () => {
    expect(pokemonServiceObj).toBeDefined();
  });

  it("should be calling getPokemonData with parameter ", () => {
    spyOn(pokemonServiceObj, "getPokemonData");
    pokemonServiceObj.getPokemonData(123);
    expect(pokemonServiceObj.getPokemonData).toHaveBeenCalledWith(123);
  });
});
