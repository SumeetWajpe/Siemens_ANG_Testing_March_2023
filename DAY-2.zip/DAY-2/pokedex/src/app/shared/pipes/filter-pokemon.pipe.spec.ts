import { FilterPokemonPipe } from "./filter-pokemon.pipe";
import { PokemonService } from "src/app/shared/services/pokemon.service";

describe("FilterPokemonPipe", () => {
  let pipe: FilterPokemonPipe;
  let pokemonService: PokemonService;

  beforeEach(() => {
    pokemonService = jasmine.createSpyObj("PokemonService", ["genderPokemons"]);
    pipe = new FilterPokemonPipe(pokemonService);
  });

  it("should return the input array if no filters are applied", () => {
    const pokemonArr = [
      { id: 1, name: "Bulbasaur", types: [{ type: { name: "grass" } }] },
      { id: 2, name: "Charmander", types: [{ type: { name: "fire" } }] },
      { id: 3, name: "Squirtle", types: [{ type: { name: "water" } }] },
    ];

    const args = { searchText: "", types: [], genders: [] };
    expect(pipe.transform(pokemonArr, args)).toEqual(pokemonArr);
  });
  it("should return the filtered Array based on search text ", () => {
    const pokemonArr = [
      { id: 1, name: "Bulbasaur", types: [{ type: { name: "grass" } }] },
      { id: 2, name: "Charmander", types: [{ type: { name: "fire" } }] },
      { id: 3, name: "Squirtle", types: [{ type: { name: "water" } }] },
    ];
    // bulb
    const args = { searchText: "bulb", types: [], genders: [] };
    const expected = [
      { id: 1, name: "Bulbasaur", types: [{ type: { name: "grass" } }] },
    ];
    expect(pipe.transform(pokemonArr, args)).toEqual(expected);
  });
});
